#pragma once

#include <vector>

// �P����3D�{�N�Z���\���ibool�i�[�j
class VolumeData {
public:
    VolumeData(int x, int y, int z)
        : sizeX(x), sizeY(y), sizeZ(z), data(x* y* z, false) {
    }

    bool get(int x, int y, int z) const {
        return data[(z * sizeY + y) * sizeX + x];
    }

    void set(int x, int y, int z, bool value) {
        data[(z * sizeY + y) * sizeX + x] = value;
    }

    int getSizeX() const { return sizeX; }
    int getSizeY() const { return sizeY; }
    int getSizeZ() const { return sizeZ; }

private:
    int sizeX, sizeY, sizeZ;
    std::vector<bool> data;
};
