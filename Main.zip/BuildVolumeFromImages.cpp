#include "BuildVolumeFromImages.h"
#include "ImageUtils.h"
#include "common.h"

#include <map>
#include <algorithm>
#include <cstring>

namespace BuildVolumeFromImages {

    VolumeData* buildVolumeFromMultipleImages(const std::map<ViewDirection, ImageData>& images) {
        const int sizeX = 128;
        const int sizeY = 128;
        const int sizeZ = 128;

        VolumeData* volume = new VolumeData(sizeX, sizeY, sizeZ);

        // �������i�S�{�N�Z���� true �Ɂj
        for (int z = 0; z < sizeZ; ++z) {
            for (int y = 0; y < sizeY; ++y) {
                for (int x = 0; x < sizeX; ++x) {
                    volume->set(x, y, z, true);
                }
            }
        }

        // �e���_�摜���g���ă{�N�Z�����i�荞�ށiAND���Z�j
        for (const auto& [dir, img] : images) {
            if (!img.pixels || img.width <= 0 || img.height <= 0) continue;

            for (int z = 0; z < sizeZ; ++z) {
                for (int y = 0; y < sizeY; ++y) {
                    for (int x = 0; x < sizeX; ++x) {
                        // �e���_���Ƃ̎ˉe����
                        int u = 0, v = 0;

                        switch (dir) {
                        case ViewDirection::Front:
                            u = x * img.width / sizeX;
                            v = y * img.height / sizeY;
                            break;
                        case ViewDirection::Back:
                            u = (sizeX - 1 - x) * img.width / sizeX;
                            v = y * img.height / sizeY;
                            break;
                        case ViewDirection::Left:
                            u = z * img.width / sizeZ;
                            v = y * img.height / sizeY;
                            break;
                        case ViewDirection::Right:
                            u = (sizeZ - 1 - z) * img.width / sizeZ;
                            v = y * img.height / sizeY;
                            break;
                        case ViewDirection::Top:
                            u = x * img.width / sizeX;
                            v = (sizeZ - 1 - z) * img.height / sizeZ;
                            break;
                        case ViewDirection::Bottom:
                            u = x * img.width / sizeX;
                            v = z * img.height / sizeZ;
                            break;
                        }

                        int pixelIndex = (v * img.width + u) * 4;
                        unsigned char alpha = img.pixels[pixelIndex + 3];
                        bool isSilhouette = (alpha > 128);

                        if (!isSilhouette) {
                            volume->set(x, y, z, false);  // ���̎��_���猩���Ȃ� �� �{�N�Z������
                        }
                    }
                }
            }
        }

        return volume;
    }

} // namespace BuildVolumeFromImages
