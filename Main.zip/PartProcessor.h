#pragma once

#include "VolumeUtils.h"
#include "GUIState.h"
#include <vector>

class PartProcessor {
public:
    PartProcessor();

    void setSelectionRegions(const std::vector<SelectionRegion>& regions);

    // �w�肳�ꂽ�p�[�c�̈悾���𒊏o���� VolumeData ��Ԃ�
    VolumeData* process(VolumeData* inputVolume);

private:
    std::vector<SelectionRegion> regions;
};
